const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const { getDb } = require('../database/db');

router.post('/register', async function(req, res) {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password) return res.json({ error: 'All fields required' });
    if (password.length < 8) return res.json({ error: 'Password must be at least 8 characters' });

    const db = await getDb();
    const existing = await db.prepare('SELECT id FROM users WHERE email = ?').get(email.toLowerCase().trim());
    if (existing) return res.json({ error: 'An account with this email already exists' });

    const hash = await bcrypt.hash(password, 10);
    const now = new Date().toISOString();
    const result = await db.prepare(
      'INSERT INTO users (name, email, password, created_at) VALUES (?, ?, ?, ?)'
    ).run(name.trim(), email.toLowerCase().trim(), hash, now);

    req.session.userId = result.lastInsertRowid;
    req.session.userName = name.trim();
    req.session.userEmail = email.toLowerCase().trim();

    res.json({ success: true, name: name.trim(), email: email.toLowerCase().trim() });
  } catch(e) {
    console.error('Register error:', e.message);
    res.json({ error: 'Registration failed. Please try again.' });
  }
});

router.post('/login', async function(req, res) {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.json({ error: 'Email and password required' });

    const db = await getDb();
    const user = await db.prepare('SELECT * FROM users WHERE email = ?').get(email.toLowerCase().trim());
    if (!user) return res.json({ error: 'Invalid email or password' });

    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.json({ error: 'Invalid email or password' });

    req.session.userId = user.id;
    req.session.userName = user.name;
    req.session.userEmail = user.email;

    res.json({ success: true, name: user.name, email: user.email });
  } catch(e) {
    console.error('Login error:', e.message);
    res.json({ error: 'Login failed. Please try again.' });
  }
});

router.get('/me', async function(req, res) {
  if (!req.session || !req.session.userId) return res.json({ authenticated: false });
  try {
    const db = await getDb();
    const user = await db.prepare('SELECT id, name, email FROM users WHERE id = ?').get(req.session.userId);
    if (!user) return res.json({ authenticated: false });
    res.json({ authenticated: true, name: user.name, email: user.email, id: user.id });
  } catch(e) {
    res.json({ authenticated: false });
  }
});

router.post('/logout', function(req, res) {
  req.session.destroy();
  res.json({ success: true });
});

router.put('/profile', async function(req, res) {
  if (!req.session || !req.session.userId) return res.status(401).json({ error: 'Not authenticated' });
  const { name, email } = req.body;
  const db = await getDb();
  const now = new Date().toISOString();
  await db.prepare('UPDATE users SET name=?, email=?, edited_at=?, edited_by=? WHERE id=?')
    .run(name, email, now, req.session.userId, req.session.userId);
  req.session.userName = name;
  req.session.userEmail = email;
  res.json({ success: true });
});

router.put('/password', async function(req, res) {
  if (!req.session || !req.session.userId) return res.status(401).json({ error: 'Not authenticated' });
  const { currentPassword, newPassword } = req.body;
  const db = await getDb();
  const user = await db.prepare('SELECT * FROM users WHERE id=?').get(req.session.userId);
  if (!user) return res.json({ error: 'User not found' });
  const match = await bcrypt.compare(currentPassword, user.password);
  if (!match) return res.json({ error: 'Current password is incorrect' });
  const hash = await bcrypt.hash(newPassword, 10);
  await db.prepare('UPDATE users SET password=? WHERE id=?').run(hash, req.session.userId);
  res.json({ success: true });
});

router.put('/apikey', async function(req, res) {
  if (!req.session || !req.session.userId) return res.status(401).json({ error: 'Not authenticated' });
  const { api_key, fal_key } = req.body;
  const db = await getDb();
  const now = new Date().toISOString();
  if (api_key !== undefined) {
    await db.prepare('UPDATE users SET api_key=?, edited_at=?, edited_by=? WHERE id=?')
      .run(api_key || null, now, req.session.userId, req.session.userId);
  }
  if (fal_key !== undefined) {
    await db.prepare('UPDATE users SET fal_key=?, edited_at=?, edited_by=? WHERE id=?')
      .run(fal_key || null, now, req.session.userId, req.session.userId);
  }
  res.json({ success: true });
});

router.get('/apikey', async function(req, res) {
  if (!req.session || !req.session.userId) return res.status(401).json({ error: 'Not authenticated' });
  const db = await getDb();
  const user = await db.prepare('SELECT api_key, fal_key FROM users WHERE id=?').get(req.session.userId);
  res.json({ api_key: user ? (user.api_key || '') : '', fal_key: user ? (user.fal_key || '') : '' });
});

module.exports = router;
